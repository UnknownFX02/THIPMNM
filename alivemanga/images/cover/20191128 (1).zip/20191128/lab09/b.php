<?php
include "config/config.php";
include ROOT."/include/function.php";
spl_autoload_register("loadClass");
$sach = new Book();
$listCat = $sach->category();
?>
<script src="js/jquery-3.4.1.min.js"></script>
<script>
function F()
{
	$.ajax({
	url:'b_ajax.php',
	data:"ts="+ $("#ts").val()+"&ml="+ $("#cat_id").val(),
	type:"GET",
	success:function(data)
	{
		$("#ketqua").html(data);
	}
	});
}
</script>
Nhap ten sach: <input type=text id=ts >
Loai: <select id="cat_id">
		<option value=''>----</option>
		<?php
		foreach($listCat as $r)
		{
			echo "<option value='{$r['cat_id']}'>
			{$r['cat_name']} </option>";
		}
		?>
	  </select>
	  <input type="button" value="tim" onClick="F()">
<div id="ketqua"></div>