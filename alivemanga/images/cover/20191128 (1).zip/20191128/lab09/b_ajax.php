<?php
include "config/config.php";
include ROOT."/include/function.php";
spl_autoload_register("loadClass");
$sach = new Book();
$ts = $_GET['ts'];
$ml= $_GET['ml'];

$data = $sach->search2($ts, $ml);

foreach($data as $r)
{
	echo "<div>{$r['book_name']} - {$r['price']} </div>";
}