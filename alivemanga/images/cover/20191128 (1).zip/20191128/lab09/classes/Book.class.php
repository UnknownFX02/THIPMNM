<?php
class Book extends Db{
	public function getRand($n)
	{
		$sql="select book_id, book_name, img from book order by rand() limit 0, $n ";
		return $this->exeQuery($sql);	
	}
	
	public function category()
	{
		return $this->exeQuery("select * from category");
		
	}
	public function search($name,$cat_id, $page=1)
	{
		/*$name="'"."%$name%"."'";
		$cat_id="'"."$cat_id"."'";*/
		$arr = array("%$name%");
		$sql="select * from book where book_name like ?  ";
		if ($cat_id  !='') {
			$arr[]=$cat_id;
			$sql .=" and cat_id = ? ";
		}
		$from = ($page-1) * 5;
		$sql .=" limit $from, 5 ";
		return $this->exeQuery($sql, $arr);
		
	}
	
	public function search2($name,$cat_id)
	{
	
		$arr = array("%$name%");
		$sql="select * from book where book_name like ?  ";
		if ($cat_id  !='') {
			$arr[]=$cat_id;
			$sql .=" and cat_id = ? ";
		}
		return $this->exeQuery($sql, $arr);
		
	}


}
?>