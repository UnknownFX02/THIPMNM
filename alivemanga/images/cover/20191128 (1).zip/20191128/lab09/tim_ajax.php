<?php
include "config/config.php";
include ROOT."/include/function.php";
spl_autoload_register("loadClass");
$sach = new Book();
if (isset($_GET['sm']))
{
	echo "Ket qua tim kiem...";
	$book_name = isset($_GET['ts'])?$_GET['ts']:'';
	$cat_id = isset($_GET['cat_id'])?$_GET['cat_id']:'';
	$page= isset($_GET['page'])?$_GET['page']:1;
	$data = $sach->search($book_name, $cat_id, $page);
	foreach($data as $r)
	{
	echo "<div> {$r['book_name']} - {$r['cat_id']} </div> ";
	}
	
	
}
?>