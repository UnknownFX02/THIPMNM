<?php
include "config/config.php";
include ROOT."/include/function.php";
spl_autoload_register("loadClass");
$sach = new Book();
$listCat = $sach->category();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Database!</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="js/jquery-3.4.1.min.js"></script>
<script>
function F()
{
	data="ts="+$("#ts").val()+"&cat_id="+ $("#cat_id").val()+"&sm=tim";
	alert(data);
	$("#ketqua").load("tim_ajax.php?"+data);
}
</script>
</head>

<body>
<form action='index.php' method=get>
Ten sach:<input type=text name=ts id=ts>
Loai <select name=cat_id id=cat_id>
		<option value=''>-----</option>
		<?php
		foreach($listCat as $r)
		{
			?>
			<option value='<?php echo $r['cat_id'] ?>'>
			<?php echo $r['cat_name'] ?></option>
			<?php
		}
		?>
	</select>
<input type=button name=sm value='tim' onClick="F()">
</form>
<div id="ketqua">

</div>
</body>
</html>