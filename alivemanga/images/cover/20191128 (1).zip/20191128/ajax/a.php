<?php
echo $_POST['n']* $_POST['n'];