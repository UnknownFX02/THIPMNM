<?php
class Book extends Db{
	public function getRand($n)
	{
		$sql="select book_id, book_name, img from book order by rand() limit 0, $n ";
		return $this->exeQuery($sql);	
	}
	function loaiSach()
	{
		return $this->exeQuery("select * from category");
	}
	
	function search($tensach, $maloai)
	{
		$sql="select book_id, book_name from book ";
		$sql .=" where book_name like ? ";
		$arr = array("%$tensach%");
		if ($maloai !='')
		{
			$sql .=" and cat_id= ?";
			$arr[] = $maloai;
		}
		return $this->exeQuery($sql, $arr);
	}
	
}