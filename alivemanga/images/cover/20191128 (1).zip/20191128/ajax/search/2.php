<?php
//print_r($_POST);
include "config/config.php";
include "classes/Db.class.php";
include "classes/Book.class.php";
$book = new Book();
$data = $book->search($_POST['tensach'], $_POST['maloai']);
//print_r($data);
foreach($data as $r)
{
	echo "<div> {$r['book_id']} - {$r['book_name']} </div>";
}