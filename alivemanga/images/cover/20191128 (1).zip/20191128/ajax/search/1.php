<?php
include "config/config.php";
include "classes/Db.class.php";
include "classes/Book.class.php";
$book = new Book();
$loai = $book->loaiSach();
?>
<html>
<head>
<script src='js/jquery-3.4.1.min.js'></script>
<script>
function F()
		{
			tensach = $("#ts").val();
			maloai = $("#loai").val();
			$.ajax({
				url:'2.php',
				data:'tensach='+tensach+"&maloai="+maloai,
				type: "POST",
				success:function(s)
				{
					$("#ketqua").html(s);

				}
			});
		}
</script>
</head>
<body>
	Ten sach: <input id='ts'> Loai 
	<select id='loai'> 
		<option value=''>----</option>
		<?php
		foreach($loai as $r)
		{
			echo "<option value='{$r['cat_id']}'>{$r['cat_name']}</option>";
		}
		?>
	</select>
	<input type=button value="Search" onClick="F()">
	<div id="ketqua"></div>
</body>
</html>

